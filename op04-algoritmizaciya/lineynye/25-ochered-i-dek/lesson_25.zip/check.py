import argparse
import importlib.util
import sys
from pathlib import Path

parser = argparse.ArgumentParser()
parser.add_argument("--stream", action="store_true")
parser.add_argument("--extra", action="store_true")
args = parser.parse_args()
root = Path(__file__).resolve().parent

def load(name):
    spec = importlib.util.spec_from_file_location(name, root / (name + ".py"))
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module

solution = load("solution")
tests = load("tests")
for name in ["process_tasks", "max_window", "iter_max_window", "RingQueue"]:
    setattr(tests, name, getattr(solution, name))
failed = 0
count = 0
for name in sorted(vars(tests)):
    if not name.startswith("test_"):
        continue
    if name.startswith("test_stream") or name in ["test_short_stream", "test_consumption"]:
        if not args.stream:
            continue
    if name.startswith("test_ring") and not args.extra:
        continue
    count += 1
    try:
        getattr(tests, name)()
        print("PASS", name)
    except Exception as error:
        failed += 1
        print("FAIL", name, type(error).__name__, str(error))
print(f"{count-failed}/{count} passed")
sys.exit(bool(failed))
