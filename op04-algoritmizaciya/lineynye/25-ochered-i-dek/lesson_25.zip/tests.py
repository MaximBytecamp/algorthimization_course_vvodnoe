def test_fifo():
    assert process_tasks([("add", "A"), ("add", "B"), ("run",), ("add", "C")]) == (["A"], ["B", "C"])

def test_empty():
    assert process_tasks([]) == ([], [])
    assert process_tasks([("run",), ("run",)]) == ([], [])

def test_close():
    assert process_tasks([("add", "A"), ("add", "B"), ("close",)]) == (["A", "B"], [])
    assert process_tasks([("close",)]) == ([], [])

def test_duplicates_and_empty_id():
    assert process_tasks([("add", ""), ("add", "A"), ("add", "A"), ("close",)]) == (["", "A", "A"], [])

def test_errors():
    for commands in [[("bad",)], [("add",)], [("run", 1)], [("add", 7)], [()], ["run"], [("close",), ("add", "A")], [("close",), ("run",)], [("close",), ("close",)]]:
        try:
            process_tasks(commands)
        except ValueError:
            pass
        else:
            raise AssertionError(commands)

def test_unchanged_and_iterable():
    commands = [("add", "A"), ("run",), ("add", "B")]
    saved = commands[:]
    assert process_tasks(iter(commands)) == (["A"], ["B"])
    assert commands == saved


def test_example():
    assert max_window([4, 1, 3, 5, 2, 5], 3) == [4, 5, 5, 5]

def test_widths():
    assert max_window([3, -1, 2], 1) == [3, -1, 2]
    assert max_window([3, -1, 2], 3) == [3]

def test_equal():
    assert max_window([5, 5, 5, 5], 2) == [5, 5, 5]

def test_order_and_negatives():
    assert max_window([1, 2, 3, 4], 2) == [2, 3, 4]
    assert max_window([4, 3, 2, 1], 2) == [4, 3, 2]
    assert max_window([-4, -2, -5], 2) == [-2, -2]

def test_invalid():
    for nums, k in [([], 1), ([], 0), ([1], 0), ([1], -1), ([1], 2)]:
        try:
            max_window(nums, k)
        except ValueError:
            pass
        else:
            raise AssertionError((nums, k))

def test_reference_and_unchanged():
    for nums in [[2, 1, 2, 3, 1], [8, 1, 2, 3], [2, 2, 1, 2], [-1]]:
        saved = nums[:]
        for k in range(1, len(nums) + 1):
            assert max_window(nums, k) == [max(nums[i:i+k]) for i in range(len(nums)-k+1)]
        assert nums == saved


def test_stream_example():
    assert list(iter_max_window(iter([4, 1, 3, 5, 2, 5]), 3)) == [4, 5, 5, 5]

def test_short_stream():
    assert list(iter_max_window(iter([]), 3)) == []
    assert list(iter_max_window(iter([1, 2]), 3)) == []

def test_stream_width_one():
    assert list(iter_max_window(iter([0, -1, 0]), 1)) == [0, -1, 0]

def test_stream_invalid():
    for k in [0, -1]:
        try:
            list(iter_max_window(iter([1]), k))
        except ValueError:
            pass
        else:
            raise AssertionError(k)

def test_consumption():
    seen = []
    def source():
        for x in [4, 1, 3, 5, 2]:
            seen.append(x)
            yield x
    result = iter_max_window(source(), 3)
    assert next(result) == 4
    assert seen == [4, 1, 3]
    assert next(result) == 5
    assert seen == [4, 1, 3, 5]

def test_stream_reference():
    for nums in [[], [1], [2, 2, 1, 3], [-3, -1, -2]]:
        for k in range(1, 6):
            assert list(iter_max_window(iter(nums), k)) == [max(nums[i:i+k]) for i in range(max(0, len(nums)-k+1))]


def test_ring_fifo():
    q = RingQueue(3)
    q.push("A"); q.push("B")
    assert q.pop() == "A"
    q.push("C"); q.push("D")
    assert [q.pop(), q.pop(), q.pop()] == ["B", "C", "D"]

def test_ring_empty():
    q = RingQueue(2)
    try:
        q.pop()
    except IndexError:
        pass
    else:
        raise AssertionError("empty")
    assert q.size == 0 and q.head == 0

def test_ring_full():
    q = RingQueue(1); q.push("A")
    try:
        q.push("B")
    except OverflowError:
        pass
    else:
        raise AssertionError("full")
    assert q.pop() == "A"

def test_ring_none_and_duplicates():
    q = RingQueue(3)
    for value in [None, 1, 1]: q.push(value)
    assert [q.pop(), q.pop(), q.pop()] == [None, 1, 1]

def test_ring_invalid_capacity():
    for capacity in [0, -1]:
        try:
            RingQueue(capacity)
        except ValueError:
            pass
        else:
            raise AssertionError(capacity)

def test_ring_many_wraps():
    q = RingQueue(2)
    for value in range(25):
        q.push(value)
        assert q.pop() == value
        assert q.size == 0
