from collections import deque

def process_tasks(commands):
    raise NotImplementedError


from collections import deque

def max_window(nums, k):
    if not 1 <= k <= len(nums):
        raise ValueError("неверная ширина окна")
    candidates = deque()
    answer = []
    for i, value in enumerate(nums):
        # 1. Удалите индексы вне текущего окна.
        # 2. Удалите с конца кандидатов не сильнее value.
        # 3. Добавьте i и запишите максимум полного окна.
        raise NotImplementedError
    return answer


from collections import deque

def iter_max_window(values, k):
    raise NotImplementedError


class RingQueue:
    def __init__(self, capacity):
        if capacity < 1:
            raise ValueError("ёмкость должна быть положительной")
        self.data = [None] * capacity
        self.head = 0
        self.size = 0

    def push(self, value):
        raise NotImplementedError

    def pop(self):
        raise NotImplementedError
