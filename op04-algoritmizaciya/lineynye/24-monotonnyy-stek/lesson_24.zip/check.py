"""Independent checks for the monotonic-stack practice starter."""

from itertools import product
import random
import traceback

from solution import largest_rectangle, next_greater, warmer_days, next_smaller


def reference_next_greater(nums):
    result = []
    for i, value in enumerate(nums):
        result.append(next((candidate for candidate in nums[i + 1:] if candidate > value), -1))
    return result


def reference_warmer_days(temps):
    result = []
    for i, value in enumerate(temps):
        result.append(next((j - i for j, candidate in enumerate(temps[i + 1:], i + 1) if candidate > value), 0))
    return result


def reference_largest_rectangle(heights):
    best = 0
    for left in range(len(heights)):
        minimum = heights[left]
        for right in range(left, len(heights)):
            minimum = min(minimum, heights[right])
            best = max(best, minimum * (right - left + 1))
    return best


def all_small_arrays():
    for length in range(8):
        yield from (list(values) for values in product(range(3), repeat=length))


def test_next_greater_examples():
    assert next_greater([2, 1, 3, 2]) == [3, 3, -1, -1]
    assert next_greater([3, 3]) == [-1, -1]
    assert next_greater([1, 2, 3]) == [2, 3, -1]


def test_next_greater_empty_and_singleton():
    assert next_greater([]) == []
    assert next_greater([7]) == [-1]


def test_next_greater_equal_values_are_not_greater():
    assert next_greater([5, 5, 5]) == [-1, -1, -1]
    assert next_greater([2, 2, 3]) == [3, 3, -1]


def test_next_greater_matches_quadratic_reference():
    for values in all_small_arrays():
        assert next_greater(values) == reference_next_greater(values), values


def test_next_greater_random_reference_cases():
    rng = random.Random(2401)
    for _ in range(200):
        values = [rng.randrange(-20, 21) for _ in range(rng.randrange(0, 25))]
        assert next_greater(values) == reference_next_greater(values), values


def test_next_greater_does_not_mutate_input():
    values = [2, 1, 2, 3, 1]
    before = values.copy()
    next_greater(values)
    assert values == before


def test_warmer_days_examples():
    assert warmer_days([73, 74, 74, 71, 72]) == [1, 0, 0, 1, 0]
    assert warmer_days([30, 40, 50, 60]) == [1, 1, 1, 0]
    assert warmer_days([90, 80, 70]) == [0, 0, 0]


def test_warmer_days_empty_and_singleton():
    assert warmer_days([]) == []
    assert warmer_days([20]) == [0]


def test_warmer_days_equal_values_are_not_warmer():
    assert warmer_days([70, 70, 71]) == [2, 1, 0]
    assert warmer_days([70, 70]) == [0, 0]


def test_warmer_days_matches_quadratic_reference():
    for values in all_small_arrays():
        assert warmer_days(values) == reference_warmer_days(values), values


def test_warmer_days_random_reference_cases():
    rng = random.Random(2402)
    for _ in range(200):
        values = [rng.randrange(-20, 41) for _ in range(rng.randrange(0, 25))]
        assert warmer_days(values) == reference_warmer_days(values), values


def test_warmer_days_does_not_mutate_input():
    values = [73, 74, 74, 71, 72]
    before = values.copy()
    warmer_days(values)
    assert values == before


def test_largest_rectangle_examples():
    assert largest_rectangle([2, 1, 5, 6, 2, 3]) == 10
    assert largest_rectangle([2, 4]) == 4
    assert largest_rectangle([6, 2, 5, 4, 5, 1, 6]) == 12


def test_largest_rectangle_empty_and_singleton():
    assert largest_rectangle([]) == 0
    assert largest_rectangle([7]) == 7
    assert largest_rectangle([0]) == 0


def test_largest_rectangle_equal_and_monotone_values():
    assert largest_rectangle([3, 3, 3]) == 9
    assert largest_rectangle([1, 2, 3, 4]) == 6
    assert largest_rectangle([4, 3, 2, 1]) == 6


def test_largest_rectangle_matches_quadratic_reference():
    for values in all_small_arrays():
        assert largest_rectangle(values) == reference_largest_rectangle(values), values


def test_largest_rectangle_random_reference_cases():
    rng = random.Random(2403)
    for _ in range(200):
        values = [rng.randrange(0, 21) for _ in range(rng.randrange(0, 25))]
        assert largest_rectangle(values) == reference_largest_rectangle(values), values


def test_largest_rectangle_does_not_mutate_input():
    values = [2, 1, 5, 6, 2, 3]
    before = values.copy()
    largest_rectangle(values)
    assert values == before



def test_next_smaller_examples():
    assert next_smaller([4, 2, 3, 1]) == [2, 1, 1, -1]

def test_next_smaller_empty_singleton():
    assert next_smaller([]) == []
    assert next_smaller([4]) == [-1]

def test_next_smaller_equal():
    assert next_smaller([2, 2]) == [-1, -1]

def test_next_smaller_monotone():
    assert next_smaller([1, 2, 3]) == [-1, -1, -1]
    assert next_smaller([3, 2, 1]) == [2, 1, -1]

def test_next_smaller_reference():
    for values in all_small_arrays():
        want = [next((v for v in values[i+1:] if v < x), -1) for i, x in enumerate(values)]
        assert next_smaller(values) == want

def test_next_smaller_unchanged_and_negative():
    values = [-1, -2, -2, -3]
    saved = values[:]
    assert next_smaller(values) == [-2, -3, -3, -1]
    assert values == saved


def run():
    tests = [
        (name, test) for name, test in sorted(globals().items())
        if name.startswith("test_") and callable(test)
        and ("--extra" in __import__("sys").argv or not name.startswith("test_largest_rectangle"))
    ]
    failures = []
    for name, test in tests:
        try:
            test()
        except Exception:
            failures.append(name)
            traceback.print_exc()
    if failures:
        print(f"FAILED: {len(failures)}/{len(tests)} tests")
        return 1
    print(f"PASS: {len(tests)} tests")
    return 0


if __name__ == "__main__":
    raise SystemExit(run())
