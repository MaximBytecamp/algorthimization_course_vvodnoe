def next_greater(nums):
    raise NotImplementedError


def warmer_days(temps):
    raise NotImplementedError


def largest_rectangle(heights):
    raise NotImplementedError


def next_smaller(nums):
    raise NotImplementedError
