def is_balanced(text):
    # text содержит только ()[]{}; пустая строка правильная.
    raise NotImplementedError


def eval_rpn(tokens):
    # Список токенов: целые числа либо + - * /.
    # Ошибка формы -> ValueError; деление на ноль -> ZeroDivisionError.
    raise NotImplementedError


def apply_actions(actions):
    # Действия: ('add', строка) либо ('undo',).
    # Отмена при пустой истории ничего не меняет.
    raise NotImplementedError
