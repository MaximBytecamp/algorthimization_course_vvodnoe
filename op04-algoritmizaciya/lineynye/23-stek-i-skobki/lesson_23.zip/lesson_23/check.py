from solution import is_balanced, eval_rpn, apply_actions

def test_brackets_empty():
    """пустая строка"""
    assert is_balanced('') is True

def test_brackets_nested():
    """вложенные и соседние пары"""
    assert is_balanced('{[()]}()') is True

def test_brackets_crossed():
    """равных счётчиков недостаточно"""
    assert is_balanced('([)]') is False

def test_brackets_early_close():
    """закрытие до открытия"""
    assert is_balanced(')(') is False

def test_brackets_unclosed():
    """остаток в стеке"""
    assert is_balanced('(()') is False

def test_brackets_many():
    """все три типа и длинная вложенность"""
    for text in ['()', '[]', '{}', '([]{})', '('*500 + ')'*500]:
        assert is_balanced(text) is True
    assert is_balanced('{]') is False


def raises(kind, tokens):
    try:
        eval_rpn(tokens)
    except kind:
        return
    assert False, 'Ожидалось исключение ' + kind.__name__

def test_rpn_operations():
    """все операции и порядок аргументов"""
    assert eval_rpn(['2', '3', '+', '4', '*']) == 20
    assert eval_rpn(['8', '3', '-']) == 5
    assert eval_rpn(['8', '2', '/']) == 4

def test_rpn_negative():
    """деление к нулю при разных знаках"""
    assert eval_rpn(['-7', '3', '/']) == -2
    assert eval_rpn(['7', '-3', '/']) == -2
    assert eval_rpn(['-7', '-3', '/']) == 2
    assert eval_rpn(['-2', '3', '*']) == -6

def test_rpn_large_and_unchanged():
    """без float и без изменения входа"""
    tokens = [str(10**80 + 2), '3', '/']
    copy = tokens[:]
    assert eval_rpn(tokens) == (10**80 + 2) // 3
    assert tokens == copy

def test_rpn_shape():
    """пусто, лишнее число, нехватка операндов"""
    for tokens in [[], ['1', '2'], ['+'], ['1', '+'], ['1', '2', '+', '+']]:
        raises(ValueError, tokens)

def test_rpn_bad_token():
    """неизвестная операция и дробный токен"""
    for tokens in [['2', '3', '^'], ['2.5']]:
        raises(ValueError, tokens)

def test_rpn_zero():
    """деление на ноль"""
    raises(ZeroDivisionError, ['5', '0', '/'])
    assert eval_rpn(['0']) == 0


def test_undo_empty():
    """пустая история"""
    assert apply_actions([]) == ''

def test_undo_lifo():
    """отменяется последнее добавление целиком"""
    assert apply_actions([('add', 'при'), ('add', 'вет'), ('undo',)]) == 'при'

def test_undo_extra_undo():
    """лишняя отмена безопасна"""
    assert apply_actions([('undo',), ('add', 'a'), ('undo',), ('undo',)]) == ''

def test_undo_new_after_undo():
    """новое добавление после отмены"""
    assert apply_actions([('add', 'a'), ('add', 'b'), ('undo',), ('add', 'c')]) == 'ac'

def test_undo_empty_chunk():
    """пустой фрагмент тоже действие"""
    assert apply_actions([('add', 'a'), ('add', ''), ('undo',)]) == 'a'

def test_undo_unchanged():
    """исходный список действий сохраняется"""
    actions = [('add', 'ab'), ('add', 'в'), ('undo',)]
    saved = actions[:]
    assert apply_actions(actions) == 'ab'
    assert actions == saved


if __name__ == '__main__':
    tests = [(name, fn) for name, fn in list(globals().items())
             if name.startswith('test_') and callable(fn)]
    for name, fn in tests:
        fn()
        print('OK:', name)
    print('Пройдено проверок:', len(tests))
