import sys
from solution import Node, reverse, merge, middle, has_cycle

def chain(values):
    nodes = [Node(value) for value in values]
    for left, right in zip(nodes, nodes[1:]):
        left.next = right
    return (nodes[0] if nodes else None), nodes

def objects(head, limit):
    result = []
    while head is not None:
        assert len(result) < limit, "Лишний узел или цикл в результате"
        result.append(head)
        head = head.next
    return result

def same_objects(actual, expected):
    assert len(actual) == len(expected), "Изменилось число узлов"
    assert all(a is b for a, b in zip(actual, expected)), "Нарушены идентичность или порядок узлов"

def test_reverse_empty():
    """пустой вход"""
    assert reverse(None) is None

def test_reverse_one():
    """один исходный объект"""
    head = Node(8)
    assert reverse(head) is head and head.next is None

def test_reverse_order_and_identity():
    """те же объекты в обратном порядке"""
    head, nodes = chain([5, 8, 2])
    result = reverse(head)
    same_objects(objects(result, 3), nodes[::-1])
    assert nodes[0].next is None
    assert [n.value for n in nodes] == [5, 8, 2]

def test_reverse_duplicates():
    """равные значения не заменяют идентичность"""
    head, nodes = chain([7, 7])
    same_objects(objects(reverse(head), 2), nodes[::-1])

def test_reverse_double_reverse():
    """два разворота восстанавливают связи"""
    head, nodes = chain([1, 2, 3, 4, 5])
    result = reverse(reverse(head))
    same_objects(objects(result, 5), nodes)

def test_merge_empty():
    """два пустых входа"""
    assert merge(None, None) is None

def test_merge_one_empty():
    """пустой вход с каждой стороны"""
    for empty_left in (True, False):
        head, nodes = chain([2, 4])
        result = merge(None, head) if empty_left else merge(head, None)
        same_objects(objects(result, 2), nodes)

def test_merge_interleaved():
    """порядок и оба узла с равным значением"""
    left, a = chain([1, 4])
    right, b = chain([2, 4])
    result = merge(left, right)
    same_objects(objects(result, 4), [a[0], b[0], a[1], b[1]])
    assert [n.value for n in a + b] == [1, 4, 2, 4]

def test_merge_remaining_tail():
    """остаток длиннее одного узла с каждой стороны"""
    for swap in (False, True):
        left, a = chain([1])
        right, b = chain([2, 3, 4])
        result = merge(right, left) if swap else merge(left, right)
        same_objects(objects(result, 4), a + b)

def test_merge_all_equal():
    """все левые равные узлы перед правыми"""
    left, a = chain([7, 7])
    right, b = chain([7, 7])
    same_objects(objects(merge(left, right), 4), a + b)

def test_middle_empty():
    """пустой вход"""
    assert middle(None) is None

def test_middle_lengths():
    """длины от 1 до 6, правая середина"""
    for size in range(1, 7):
        head, nodes = chain(range(size))
        assert middle(head) is nodes[size // 2], f"Неверный узел при длине {size}"

def test_middle_unchanged_links():
    """все исходные связи сохраняются"""
    head, nodes = chain([4, 1, 9, 2, 8])
    before = [n.next for n in nodes]
    assert middle(head) is nodes[2]
    assert all(n.next is link for n, link in zip(nodes, before))

def test_middle_equal_values():
    """сравнивается объект, а не значение"""
    head, nodes = chain([7, 7, 7, 7])
    assert middle(head) is nodes[2]

def test_has_cycle_empty():
    """пустой вход"""
    assert has_cycle(None) is False

def test_has_cycle_no_cycle():
    """длины 1–5, в том числе одинаковые значения"""
    for size in range(1, 6):
        head, nodes = chain([7] * size)
        assert has_cycle(head) is False

def test_has_cycle_self_loop():
    """самоссылка"""
    head = Node(8)
    head.next = head
    assert has_cycle(head) is True
    assert head.next is head

def test_has_cycle_cycle_entries():
    """каждый вход в цикл и сохранение связей"""
    for entry in range(5):
        head, nodes = chain([7, 7, 9, 4, 5])
        nodes[-1].next = nodes[entry]
        before = [n.next for n in nodes]
        assert has_cycle(head) is True
        assert all(n.next is link for n, link in zip(nodes, before))

def test_has_cycle_overridden_equality():
    """__eq__ не определяет встречу"""
    class EqualNode(Node):
        def __eq__(self, other):
            return True
    a = EqualNode(1)
    b = EqualNode(2)
    c = EqualNode(3)
    a.next, b.next = b, c
    assert has_cycle(a) is False

if __name__ == "__main__":
    allowed = {"reverse", "merge", "middle", "has_cycle"}
    chosen = set(sys.argv[1:]) or allowed
    unknown = chosen - allowed
    if unknown:
        raise SystemExit("Неизвестные функции: " + ", ".join(sorted(unknown)))
    tests = [(name, fn) for name, fn in list(globals().items())
             if callable(fn) and any(name.startswith("test_" + task + "_") for task in chosen)]
    failed = 0
    for name, fn in tests:
        try:
            fn()
            print("OK", name)
        except Exception as exc:
            failed += 1
            print("FAIL", name, type(exc).__name__, str(exc))
    print(f"Прошло: {len(tests) - failed} из {len(tests)}")
    raise SystemExit(bool(failed))
