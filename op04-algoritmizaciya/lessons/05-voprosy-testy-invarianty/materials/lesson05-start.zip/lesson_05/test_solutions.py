"""Начальные проверки. Добавьте минимум пять случаев на каждую задачу."""
import unittest
from solutions import second_max, contains_zero, is_sorted


class SolutionsTests(unittest.TestCase):
    def test_second_max(self):
        self.assertEqual(second_max([1, 5, 3]), 3)
        # Добавьте границы, дубликаты, отрицательные числа и отсутствие ответа.

    def test_contains_zero(self):
        self.assertTrue(contains_zero([0, 4]))
        # Добавьте пустой список, один элемент, ноль в конце и отсутствие нуля.

    def test_is_sorted(self):
        self.assertTrue(is_sorted([1, 2, 3]))
        # Добавьте равенство, пустой список и нарушение порядка.


if __name__ == "__main__":
    unittest.main()
