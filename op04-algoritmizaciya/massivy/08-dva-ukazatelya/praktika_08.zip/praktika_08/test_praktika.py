from solution import merge_unique
import random
import time


def _forbidden(name):
    def stub(*args, **kwargs):
        raise AssertionError(f"по условию {name} использовать нельзя")
    return stub


def _expected(a, b):
    return sorted(set(a) | set(b))


def test_example():
    """пример из условия"""
    assert merge_unique([1, 3, 3, 7], [2, 3, 8]) == [1, 2, 3, 7, 8]


def test_both_empty():
    """оба списка пустые"""
    assert merge_unique([], []) == []


def test_first_empty():
    """первый пустой, во втором повторы"""
    assert merge_unique([], [4, 4, 5]) == [4, 5]


def test_second_empty():
    """второй пустой"""
    assert merge_unique([1, 2, 2, 9], []) == [1, 2, 9]


def test_single_each():
    """по одному элементу, одинаковые"""
    assert merge_unique([7], [7]) == [7]


def test_all_same():
    """все элементы обоих списков одинаковые"""
    assert merge_unique([5, 5, 5], [5, 5]) == [5]


def test_same_lists():
    """два одинаковых списка"""
    assert merge_unique([1, 2, 3], [1, 2, 3]) == [1, 2, 3]


def test_first_before_second():
    """все числа первого меньше всех чисел второго"""
    assert merge_unique([1, 2], [10, 20, 30]) == [1, 2, 10, 20, 30]


def test_second_before_first():
    """все числа второго меньше всех чисел первого"""
    assert merge_unique([10, 20, 30], [1, 2]) == [1, 2, 10, 20, 30]


def test_interleaved():
    """числа списков чередуются"""
    assert merge_unique([1, 3, 5, 7], [2, 4, 6, 8]) == [1, 2, 3, 4, 5, 6, 7, 8]


def test_long_tail_with_repeats():
    """хвост одного списка с повторами после конца другого"""
    assert merge_unique([1, 2], [2, 6, 6, 6, 9, 9]) == [1, 2, 6, 9]


def test_repeat_across_lists():
    """одно значение повторяется в конце первого и в начале второго"""
    assert merge_unique([1, 4, 4], [4, 4, 8]) == [1, 4, 8]


def test_negative_and_zero():
    """отрицательные числа и ноль"""
    assert merge_unique([-5, -5, 0, 3], [-7, -5, 0, 0]) == [-7, -5, 0, 3]


def test_big_numbers():
    """большие числа"""
    assert merge_unique([10**12, 10**15], [10**12 + 1]) == [10**12, 10**12 + 1, 10**15]


def test_inputs_not_changed():
    """входные списки не меняются"""
    a, b = [1, 1, 4], [2, 4, 4]
    merge_unique(a, b)
    assert a == [1, 1, 4] and b == [2, 4, 4], f"после вызова a = {a}, b = {b}"


def test_new_list():
    """результат — новый список, а не один из входных"""
    a, b = [1, 2, 3], []
    res = merge_unique(a, b)
    assert res is not a and res is not b, "функция вернула входной список вместо нового"


def test_no_builtin_sorting():
    """sorted, set и dict не используются"""
    g = merge_unique.__globals__
    saved = {name: g[name] for name in ("sorted", "set", "dict") if name in g}
    for name in ("sorted", "set", "dict"):
        g[name] = _forbidden(name)
    try:
        assert merge_unique([1, 1, 5, 6], [0, 5, 9]) == [0, 1, 5, 6, 9]
    finally:
        for name in ("sorted", "set", "dict"):
            del g[name]
        g.update(saved)


def test_random_small():
    """400 случайных пар списков длиной до 12"""
    rnd = random.Random(8)
    for _ in range(400):
        a = sorted(rnd.randint(-5, 5) for _ in range(rnd.randint(0, 12)))
        b = sorted(rnd.randint(-5, 5) for _ in range(rnd.randint(0, 12)))
        got = merge_unique(list(a), list(b))
        assert got == _expected(a, b), f"merge_unique({a}, {b}) вернула {got}, нужно {_expected(a, b)}"


def test_big_input_is_fast():
    """по 20 000 чисел в каждом списке быстрее чем за 1 секунду"""
    rnd = random.Random(80)
    a = sorted(rnd.randint(0, 30000) for _ in range(20000))
    b = sorted(rnd.randint(0, 30000) for _ in range(20000))
    start = time.perf_counter()
    got = merge_unique(a, b)
    spent = time.perf_counter() - start
    assert got == _expected(a, b), "на большом входе ответ неверный"
    assert spent < 1.0, f"работает {spent:.2f} с: похоже, решение не O(n + m)"
