def print_report(lines):
    for line in lines:
        print(line)
