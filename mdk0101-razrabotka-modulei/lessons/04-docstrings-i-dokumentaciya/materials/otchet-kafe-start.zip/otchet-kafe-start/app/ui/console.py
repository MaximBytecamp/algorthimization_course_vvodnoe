def print_report(lines: list[str]) -> None:
    for line in lines:
        print(line)
